package com.example.artelista.model

import java.io.Serializable

class evento: Serializable
{            var tituloevento: String=""
             var categoriaevento:  String=""
             var horaevento:  String=""
}


