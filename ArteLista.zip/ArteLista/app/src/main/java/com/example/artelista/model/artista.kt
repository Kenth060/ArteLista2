package com.example.artelista.model

import java.io.Serializable

class artista : Serializable {
            var nombreartista: String=""
            var categoriaartista:  String=""
            var paisartista:String=""
}