package com.example.artelista.model
import  java.io.Serializable
class galeria:Serializable{
    var artistagaleria: String=""
    var preciogaleria:  String=""
    var imagengaleria:  String=""
    var titulogaleria:  String=""
    var perfilgaleria: String=""
}